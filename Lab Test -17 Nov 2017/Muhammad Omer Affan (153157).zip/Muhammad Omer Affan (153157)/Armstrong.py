number = input('Enter a Num: ')
length = len(number)
result = 0
for all in number:
    result += int(all)**length

print(result)

if result == int(number):
    print('Number is ArmStrong!')
else:
    print('Number is not ArmStrong!')
