one = int(input("How many for first List: "))
ListOne = []
for i in range(one):
    ListOne.append(input('Enter Num: '))

print(ListOne)

two = int(input("How many for second List: "))
ListTwo = []
for i in range(two):
    ListTwo.append(input('Enter Num: '))

print(ListTwo)

x = set(ListOne)
y = set(ListTwo)

first = list(x-y)
second = list(y-x)
print('First list =', first, '\n')
print('Second list =', second, '\n')
result = first + second

print(result)
