import random
rnum = random.randint(1,20)
unum = int(input('Enter Any Num From 1 to 20: '))
while True:
    if unum == rnum:
        print('You Win, Number Is: ', rnum)
        break
    else:
        print('Try Again..')
        unum = int(input('Enter Any Num From 1 to 20: '))
