import random
guessed=False
while guessed==False:
    print("A random number has been generated...\n")
    userInput = int(input("Enter the number you think would be 'THE LUCKY ONE': "))
    randomNumber = random.randrange(0,50)
    if userInput==randomNumber:
        guessed = True
        print("Well done!")
    elif userInput>50:
        print("Our guess range is between 0 and 50, please try a bit lower")
    elif userInput<0:
        print("Our guess range is between 0 and 50, please try a bit higher")
    elif userInput!=randomNumber:
        print'Try one more time , generated number was', randomNumber
