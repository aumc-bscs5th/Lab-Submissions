x = input('Enter A String: ')
palindrome = x[::-1]
if palindrome == x:
    print('Input Sring is Palindrome')
else:
    print('Input Sring is not a Palindrome')

x = input('Enter An Integer: ')
palindrome = x[::-1]
if palindrome == x:
    print('Input Integer is Palindrome')
else:
    print('Input Integer is not a Palindrome')
