import random
guess=99
count=0
no = random.randint(1,20)
print("Welcome to the guessing game!")
while guess != no :
    guess = int(input("Guess a number: "))
    if guess < no :
        print("Number is lower")
        count+=1
    if guess > no :
        print("Higher")
        count+=1
    if (guess==no):
        print("You win, the number was indeed:",no)
        print("It took you a total of:",count,"tries")
print (no)
