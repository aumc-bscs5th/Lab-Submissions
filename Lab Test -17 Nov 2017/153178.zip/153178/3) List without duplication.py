first_list = [1,3,5,7,9,11,13,15]
second_list = [1,2,3,4,5,6,7,8,9]
in_first = set(first_list)
in_second = set(second_list)
in_second_but_not_in_first = in_second - in_first
result = first_list + list(in_second_but_not_in_first)
print result
