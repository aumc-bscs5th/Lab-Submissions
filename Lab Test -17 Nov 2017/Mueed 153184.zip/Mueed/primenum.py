for num in range(2,50):
    prime = True
    for i in range(2,num):
        if (num%i==0):
            prime = False
    if prime:
       print ("Prime number: "+str(num))

