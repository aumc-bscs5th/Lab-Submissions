# string is palindrome or not

my_str = raw_input("Enter the string you want to check: ")

# checking the string
rev_str = reversed(my_str)

# check if the string is palindrome or not
if list(my_str) == list(rev_str):
   print("It is palindrome")
else:
   print("It is not palindrome")
