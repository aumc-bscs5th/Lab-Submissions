for num in range(2,45):
    prime = True
    for i in range(2,num):
        if (num%i==0):
            prime = False
    if prime:
        print (num)


n = 15
s = 0
counter = 1
while counter <= n:
     s +=num
     counter += 1

print("Sum of first 15 num is ",s)


