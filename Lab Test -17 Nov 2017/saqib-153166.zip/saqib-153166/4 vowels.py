x = input('Input charactors : ')
z = []
count = 0
for i in x:
    if i == 'a':
        z.append(i)
        count += 1
    elif i == 'e':
       z.append(i)
       count += 1
    elif i == 'i':
       z.append(i)
       count += 1
    elif i == 'o':
       z.append(i)
       count += 1
    elif i == 'u':
       z.append(i)
       count += 1

print(z,'Total vowels:', count)


input('return ')
