number=input("Enter a number")
number2=input("Enter another Number")
first=list (number)
second=list (number2)
third = set(first)
fourth = set(second)
in_fourth_but_not_in_third = fourth - third
result = first + list(in_fourth_but_not_in_third)
print (result)

input("Return ")
