
# Python Program to Reverse a Number using While loop
Number = int(input("Please Enter any Number: "))
Temp=Number
Reverse = 0
while(Number > 0):
    Reminder = Number %10
    Reverse = (Reverse *10) + Reminder
    Number = Number //10
if Temp==Reverse:
    print("\n This is a palindrome number = %d" %Reverse)
else:
    print("\n This is not palindrome number = %d" %Reverse)

