# Enter 2 Lists in 3rd List
# and print without duplication

# First List
first = [4, 9, 3, 4]

# Second List
second = [3, 2, 3, 6, 1]

# Mashing First 2 lists in 3
third = [set(first) | set(second)]
# Using the UNION Operator'|'
print (third)