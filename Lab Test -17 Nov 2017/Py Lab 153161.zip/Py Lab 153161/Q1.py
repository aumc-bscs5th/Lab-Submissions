# Program to check if input is
# is palindrome or not

# change this value for a different output
input_string = str(input("Input value for comparison > > "))

# reverse input string
reverse_string = reversed(input_string)

# compare input_string to reverse_string
if list(input_string) == list(reverse_string):
   print("It is palindrome")
else:
   print("It is not palindrome")
