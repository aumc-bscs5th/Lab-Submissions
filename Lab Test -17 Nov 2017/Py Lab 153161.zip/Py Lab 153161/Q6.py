# Make a Guess Number Game

# Generate a random number between 0 and 9

# Import the random module from Lib

import random
import time

Guess = input("Guess the Number > > ").lower()

rand_num = 23

while(Guess != rand_num):
    rand_num = random.randint (0, 20)
    print (". ")
    time.sleep (.5)

    print (". ")
    time.sleep (.5)

    print (". ")
    time.sleep (.5)

    if rand_num == Guess:
        print ("\n\t\tCORRECT!!!\n\tYOU HAVE WON!!!")
        break
    else:
        print("INCORRECT!!! \nTHE CORRECT NUMBER WAS: !!!")
        print (rand_num)
    Guess = input ("Guess the Number > > ")


