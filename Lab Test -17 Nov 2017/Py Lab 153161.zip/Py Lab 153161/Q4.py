# Write a string and find the vowels
# Find number of vowels in string


# Declare a variable named count
count = 0

# Get Input ansd Convert all to lower form
string = input("Type a sentence > > ").lower()

for alph in string:
# Check if alph is in Provided string
    if alph in 'aeiou':
        # Check if alph is in aeiou
        count += 1
# Print Final Count
print (count)