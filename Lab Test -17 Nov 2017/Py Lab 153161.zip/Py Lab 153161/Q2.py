# Write Function to write sum of
# first 15 prime numbers

sum=0
# Since 15th Prime number is > > 41
max=42

for n in range(2,max):
  if all(n % i for i in range(2, n)):
    sum += n
# Calculate Sum
print (sum)