import random


guess=99 

count=0  

no = random.randint(1,50)  


print("Welcome to the guessing game!")

print(no)

while guess != no :  
    guess = int(input("Guess a number: ")) 

    if guess < no : 
        print("Higher") 
        count+=1  

    if guess > no :
        print("Lower") 
        count+=1  

    if (guess==no):
        print("You win, the number was indeed:",no)
        print("It took you a total of:",count,"tries")
