num = input('Enter A Num: ')
rslt = 0
for i in num:
    rslt += int(i)**3

print(rslt)

if rslt == int(num):
    print('Number is ArmStrong!')
else:
    print('Number is not ArmStrong!')
