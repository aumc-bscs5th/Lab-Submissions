import random
rnum = random.randint(1,50)
x = int(input("Enter Any Num From 1 to 50:"))
while True:
    if x == rnum:
        print("You Win, Number Is: ",rnum)
        break
    else:
        print("Try Again..")
        x = int(input("Enter Any Num From 1 to 20:"))
