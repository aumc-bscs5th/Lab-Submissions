#153198
#Zeeshan Waheed
#write a python Program to check if a string
#is palindrome or not

my_str = input("Enter a string to check it is palindrome or not? ")

# using casefold() function for caseless comparison
my_str = my_str.casefold()

# reverse the string
rev_str = reversed(my_str)

# check if the string is equal to its reverse
if list(my_str) == list(rev_str):
   print("It is palindrome")
else:
   print("It is not palindrome")


my_value = input("Enter a number to check it is palindrome or not? " )

my_value = my_value.casefold()

rev_value = reversed(my_value)

if list(my_value) == list(rev_value):
   print("It is palindrome")

else:
   print("It is not palindrome")
   
