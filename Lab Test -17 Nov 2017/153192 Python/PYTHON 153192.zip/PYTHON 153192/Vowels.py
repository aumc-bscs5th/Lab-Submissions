x = input('Enter the string:')
li = []
count = 0
for i in x:
    if i == 'a':
        li.append(i)
        count += 1
    elif i == 'e':
       li.append(i)
       count += 1
    elif i == 'i':
       li.append(i)
       count += 1
    elif i == 'o':
       li.append(i)
       count += 1
    elif i == 'u':
       li.append(i)
       count += 1

print(li,"Vowels:", count)
