str = input("Enter A Num:")
l=len(str)
result = 0
for i in str:
    result = result + int(i)**l

print(result)

if result == int(str):
    print("Number is ArmStrong!")
else:
    print("Number is not ArmStrong!")
