x = input("Enter a Word:")
palandrome = x[::-1]
if palandrome == x:
    print("Word is Paladrome")
else:
    print("Word is not a Paladrome")




x = input("Enter a Number:")
palandrome = x[::-1]
if palandrome == x:
    print("Number is Paladrome")
else:
    print("Number is not a Paladrome")
